CREATE SEQUENCE AccountNumber_Sequence
    AS INT
    INCREMENT BY 1
    START WITH 100000104
    MINVALUE 100000101
    MAXVALUE 999999999

DROP PROC usp_OpenAccount
CREATE PROCEDURE usp_OpenAccount
(
    @CustomerId BIGINT,
    @BranchId TINYINT,
    @TellerId TINYINT,
    @AccountNumber VARCHAR(15) OUTPUT 
)
AS
BEGIN
    DECLARE @SequenceValue VARCHAR(9), @BranchCode VARCHAR(6)
    BEGIN TRY
        IF NOT EXISTS (SELECT CustomerId FROM Customer WHERE CustomerId = @CustomerId)
        BEGIN
            RETURN -1
        END
        IF NOT EXISTS (SELECT BranchId FROM Branch WHERE BranchId = @BranchId)
        BEGIN
            RETURN -2
        END
        IF NOT EXISTS (SELECT TellerId FROM Teller WHERE TellerId = @TellerId)
        BEGIN
            RETURN -3
        END
        SELECT @SequenceValue = NEXT VALUE FOR AccountNumber_Sequence
        SELECT @BranchCode=BranchCode FROM Branch WHERE BranchId = @BranchId
        SELECT @AccountNumber = @BranchCode + @SequenceValue
            BEGIN TRAN
                INSERT INTO Account(AccountNumber, BranchId, CreatedBy)
                VALUES(@AccountNumber, @BranchId, @TellerId)
                INSERT INTO AccountCustomerMapping(AccountNumber, CustomerId)
                VALUES(@AccountNumber, @CustomerId)
            COMMIT
            RETURN 1
    END TRY
    BEGIN CATCH
        ROLLBACK
        RETURN -99
    END CATCH
END
GO


BEGIN
	DECLARE @AccountNumber VARCHAR(15), @ReturnValue INT
	EXEC @ReturnValue = usp_OpenAccount '1000000060', 1, 5, @AccountNumber OUT
	SELECT @AccountNumber AS AccountNumber
	SELECT @ReturnValue AS ReturnValue
END

create proc usp_p1
(@n1 int,@n2 int =10,@n3 int)
with encryption
as
begin
	print 'hi'
end

exec usp_p1 5,@n3=20



CREATE function ufn_f1(@val int)
RETURNS varchar(5)
AS
BEGIN
	declare @local_val varchar(5) 
	
	if (@val>10)
		set @local_val='g'
	else 
		set @local_val='s'
return @local_val
END

select [ITILInfosys/rohan12.TRN].ufn_f1(11)
EXEC ufn_f1(15)


-----------------------


CREATE FUNCTION ufn_GetTransactionsForType
(
	@AccountNumber VARCHAR(15),
	@TransactionType VARCHAR(10)
)
RETURNS @Transactions TABLE 
(TransactionId BIGINT, Amount MONEY, TransactionDateTime SMALLDATETIME,
 Mode VARCHAR(20),Remarks VARCHAR(30))
AS
BEGIN
	IF @TransactionType = 'Credit'
	BEGIN
		INSERT @Transactions
		SELECT TransactionId, Amount, TransactionDateTime, Mode, Remarks FROM [Transaction] WHERE AccountNumber = @AccountNumber and [Type]=1
	END
	ELSE IF @TransactionType = 'Debit'
	BEGIN
		INSERT @Transactions
		SELECT TransactionId, Amount, TransactionDateTime, Mode, Remarks FROM [Transaction] WHERE AccountNumber = @AccountNumber and [Type]=0
	END
    RETURN
END
GO