sp_help Customer

create table Customer(CustomerId bigint constraint pk_Customer_CustomerId primary key not null identity(1000000001,1),
EmailId varchar(255) constraint u_EmailId unique not null,
Name varchar(100) not null,
DateOfBirth date constraint ck_Customer_DateOfBirth check(DATEDIFF(day,DateOfBirth,GETDATE())/(365.25)>=(18)) not null,
CreatedTimestamp DATETIME2 (7)Default GetDate() not null,
CreatedBy TINYINT constraint fk_CreatedBy foreign key references Teller(TellerId) not null,
ModifiedTimestamp DATETIME2 (7),
ModifiedBy TINYINT constraint fk_ModifiedBy foreign key references Teller(TellerId) )


create table Teller(TellerId tinyint constraint pk_CustomerLogin_CustomerId primary key not null identity,
LoginName VARCHAR(5) constraint u_LoginName unique constraint ck_LoginName  check(LoginName like 'T____') not null,
[Password] varbinary(300) not null) 


drop table Teller
drop table Customer
drop table CustomerLogin


BEGIN
DECLARE @LoginName VARCHAR(5)
DECLARE @Password VARCHAR(300)

	SET @LoginName = 'T1011'
	SET @Password = 'Indy521554'
    DECLARE @RetValue INT=0
    IF EXISTS (SELECT * FROM Teller WHERE LoginName = @LoginName)
		SET @RetValue = -1 
	ELSE
		SET @RetValue=1
	IF (@RetValue!=-1)
		INSERT INTO Teller (LoginName, [Password]) 
		VALUES(@LoginName ,convert(varbinary,@Password))
		
	IF(@RetValue=-1) 
		PRINT 'Login name already exists'
	ELSE
		PRINT 'Teller details added successfully'
END

SELECT * FROM TELLER


select @@  

INSERT INTO Teller (LoginName, Password) VALUES ('T1001',CAST('Indy!123' AS VARBINARY))
INSERT INTO Teller (LoginName, Password) VALUES ('T1002',CAST('Indy!123' AS VARBINARY))
INSERT INTO Teller (LoginName, Password) VALUES ('T1003',CAST('Indy!123' AS VARBINARY))
INSERT INTO Teller (LoginName, Password) VALUES ('T1004',CAST('Indy!123' AS VARBINARY))
INSERT INTO Teller (LoginName, Password) VALUES ('T1005',CAST('Indy!123' AS VARBINARY))
INSERT INTO Teller (LoginName, Password) VALUES ('T1006',CAST('Indy!123' AS VARBINARY))
INSERT INTO Teller (LoginName, Password) VALUES ('T1007',CAST('Indy!123' AS VARBINARY))
INSERT INTO Teller (LoginName, Password) VALUES ('T1008',CAST('Indy!123' AS VARBINARY))
INSERT INTO Teller (LoginName, Password) VALUES ('T1009',CAST('Indy!123' AS VARBINARY))
INSERT INTO Teller (LoginName, Password) VALUES ('T1010',CAST('Indy!123' AS VARBINARY))



INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('mvanyashkin0@fastcompany.com' , 'Melanie Vanyashkin' , '1993/09/01' , 1 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('rstraun1@nydailynews.com' , 'Ranique Straun' , '1992/08/08' , 1 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('pkahler2@ameblo.jp' , 'Patten Kahler' , '1994/03/13' , 1 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('fhorsewood3@reverbnation.com' , 'Florenza Horsewood' , '1990/02/17' , 1 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('tgeerdts4@arizona.edu' , 'Trescha Geerdts' , '1990/02/06' , 1 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('tvacher5@odnoklassniki.ru' , 'Tyne Vacher' , '1993/08/13' , 1 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('gyarnley6@uiuc.edu' , 'Granville Yarnley' , '1988/12/04' , 1 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('cminer7@slideshare.net' , 'Conny Miner' , '1990/01/07' , 1 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('kvan8@washington.edu' , 'Karyn Van der Kruijs' , '1991/09/08' , 1 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('tgrossier9@domainmarket.com' , 'Teodoor Grossier' , '1990/12/07' , 1 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('apurslowa@thetimes.co.uk' , 'Auria Purslow' , '1988/07/26' , 2 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('adayb@ameblo.jp' , 'Andy Day' , '1990/03/17' , 2 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('dkaysorc@woothemes.com' , 'Doyle Kaysor' , '1990/06/14' , 2 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('pspatad@bloglovin.com' , 'Porty Spata' , '1988/07/10' , 2 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('ddee@google.es' , 'Dell De Cruz' , '1989/06/29' , 2 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('lconfaitf@japanpost.jp' , 'Lawrence Confait' , '1988/11/17' , 2 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('cdearyg@epa.gov' , 'Caria Deary' , '1989/04/10' , 2 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('cwindramh@t.co' , 'Claudette Windram' , '1989/10/14' , 3 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('dcoultishi@google.co.uk' , 'Dottie Coultish' , '1994/01/02' , 4 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('lavesonj@yandex.ru' , 'Lauralee Aveson' , '1993/08/16' , 3 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('btavenerk@bing.com' , 'Bryon Tavener' , '1992/09/17' , 3 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('jbullinl@hao123.com' , 'Jammal Bullin' , '1991/06/26' , 3 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('bcapplemanm@boston.com' , 'Brendon Cappleman' , '1990/01/27' , 3 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('cfilippazzon@twitter.com' , 'Christen Filippazzo' , '1994/04/06' , 3 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('rdarrelo@arizona.edu' , 'Reagan Darrel' , '1992/06/19' , 4 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('gspinksp@barnesandnoble.com' , 'Gib Spinks' , '1994/03/12' , 4 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('rmcilrathq@fastcompany.com' , 'Roseline McIlrath' , '1989/07/29' , 4 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('rmcguggyr@mapy.cz' , 'Rosina McGuggy' , '1990/05/04' , 4 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('dflewins@google.com.au' , 'Doro Flewin' , '1993/04/05' , 4 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('mdivallt@cyberchimps.com' , 'Magda Divall' , '1991/07/22' , 4 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('nstandenu@vk.com' , 'Noella Standen' , '1990/11/27' , 4 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('mcovellv@microsoft.com' , 'Michele Covell' , '1993/08/29' , 4 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('bgoutcherw@virginia.edu' , 'Benedikta Goutcher' , '1990/03/27' , 4 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('rtarrantx@ehow.com' , 'Randy Tarrant' , '1994/05/19' , 4 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('asmeey@symantec.com' , 'Aron Smee' , '1993/08/07' , 4 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('amacqueenz@sfgate.com' , 'Abey MacQueen' , '1989/08/27' , 4 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('jduckerin10@sciencedaily.com' , 'Jami Duckerin' , '1992/06/14' , 4 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('mthorburn11@moonfruit.com' , 'Mitchael Thorburn' , '1990/07/12' , 4 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('fswabey12@kickstarter.com' , 'Fiorenze Swabey' , '1990/07/23' , 4 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('ccomi13@webnode.com' , 'Christoph Comi' , '1993/03/13' , 4 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('kengland14@apple.com' , 'Kincaid England' , '1990/07/12' , 4 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('ckenningham15@yahoo.co.jp' , 'Carolynn Kenningham' , '1989/07/19' , 4 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('jbarnsdale16@timesonline.co.uk' , 'Jonell Barnsdale' , '1990/07/10' , 4 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('cpetrescu17@mozilla.org' , 'Cora Petrescu' , '1994/03/24' , 5 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('ebrasted18@webnode.com' , 'Eve Brasted' , '1990/11/28' , 5 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('egatchel19@amazon.co.uk' , 'Elbert Gatchel' , '1992/04/05' , 5 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('mfairbourn1a@forbes.com' , 'Morgen Fairbourn' , '1992/10/29' , 5 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('ttucknutt1b@freewebs.com' , 'Tillie Tucknutt' , '1993/10/16' , 5 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('blisciandro1c@dyndns.org' , 'Bartram Lisciandro' , '1993/02/05' , 5 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('ndanielli1d@senate.gov' , 'Nessy Danielli' , '1990/06/05' , 5 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('abearne1e@reddit.com' , 'Anjela Bearne' , '1988/09/28' , 5 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('lmorshead1f@sitemeter.com' , 'Linnie Morshead' , '1993/08/10' , 5 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('dwarters1g@meetup.com' , 'Darya Warters' , '1990/12/10' , 5 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('cbartolomieu1h@wired.com' , 'Colette Bartolomieu' , '1988/12/27' , 5 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('wjanoschek1i@squarespace.com' , 'Wat Janoschek' , '1989/02/26' , 5 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('bgirardez1j@telegraph.co.uk' , 'Bennie Girardez' , '1991/03/26' , 1 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('srobelow1k@nytimes.com' , 'Say Robelow' , '1989/06/19' , 1 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('hablitt1l@cocolog-nifty.com' , 'Hedvige Ablitt' , '1991/04/19' , 1 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('gbuckeridge1m@un.org' , 'Glyn Buckeridge' , '1990/01/21' , 1 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('eleece1n@phoca.cz' , 'Ericha Leece' , '1993/05/10' , 1 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('cmacneilly1o@mashable.com' , 'Catina MacNeilly' , '1993/05/11' , 1 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('mmacconchie1p@sfgate.com' , 'Milka MacConchie' , '1993/06/28' , 1 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('sbrewitt1q@arizona.edu' , 'Sherry Brewitt' , '1989/04/06' , 1 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('bheditch1r@hc360.com' , 'Bronson Heditch' , '1989/11/24' , 1 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('tfallon1s@oracle.com' , 'Tandy Fallon' , '1992/04/26' , 2 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('csherborn1t@seattletimes.com' , 'Cole Sherborn' , '1994/04/03' , 2 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('ldonoher1u@cornell.edu' , 'Lissa Donoher' , '1989/12/25' , 2 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('pblenkinsop1v@timesonline.co.uk' , 'Peder Blenkinsop' , '1990/10/10' , 2 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('smarciek1w@zimbio.com' , 'Sebastian Marciek' , '1992/01/19' , 2 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('epleaden1x@pbs.org' , 'Erminie Pleaden' , '1991/08/12' , 2 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('woddie1y@simplemachines.org' , 'Wallace Oddie' , '1989/11/11' , 2 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('dbeaton1z@tuttocitta.it' , 'Dorothee Beaton' , '1991/04/24' , 3 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('dtreeby20@utexas.edu' , 'Dyna Treeby' , '1988/08/21' , 4 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('yjeannard21@phpbb.com' , 'Yovonnda Jeannard' , '1989/09/25' , 3 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('ffobidge22@gmpg.org' , 'Fernandina Fobidge' , '1989/12/21' , 3 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('dkorous23@tmall.com' , 'Danny Korous' , '1989/03/29' , 3 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('rdanslow24@oaic.gov.au' , 'Rolf Danslow' , '1988/12/13' , 3 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('tnorcop25@so-net.ne.jp' , 'Tito Norcop' , '1993/09/23' , 3 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('johogertie26@china.com.cn' , 'Jourdan O Hogertie' , '1992/09/25' , 4 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('hgrece27@blinklist.com' , 'Hewitt Grece' , '1990/07/15' , 4 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('kseaking28@purevolume.com' , 'Kristoforo Seaking' , '1993/10/05' , 4 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('aweildish29@upenn.edu' , 'Annadiana Weildish' , '1993/08/02' , 4 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('pdemead2a@hatena.ne.jp' , 'Prentice Demead' , '1993/02/23' , 4 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('mlavall2b@blogger.com' , 'Mireielle Lavall' , '1989/03/25' , 4 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('mkorb2c@sakura.ne.jp' , 'Mic Korb' , '1989/04/18' , 4 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('alitchmore2d@europa.eu' , 'Anne Litchmore' , '1994/02/11' , 4 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('gsainteau2e@behance.net' , 'Gwenny Sainteau' , '1993/04/27' , 4 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('lnarramore2f@wix.com' , 'Lyndy Narramore' , '1990/02/02' , 4 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('anode2g@vkontakte.ru' , 'Agosto Node' , '1988/06/13' , 4 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('tshuxsmith2h@symantec.com' , 'Thain Shuxsmith' , '1993/12/29' , 4 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('foakwell2i@dot.gov' , 'Faun Oakwell' , '1990/01/27' , 4 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('gemps2j@home.pl' , 'Giffy Emps' , '1994/02/18' , 4 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('haizikov2k@timesonline.co.uk' , 'Holli Aizikov' , '1994/03/02' , 4 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('reberlein2l@mediafire.com' , 'Rafaello Eberlein' , '1994/04/09' , 4 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('ksaffe2m@uiuc.edu' , 'Kelsey Saffe' , '1988/07/30' , 4 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('owyness2n@google.fr' , 'Osborn Wyness' , '1993/02/27' , 4 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('edevote2o@webeden.co.uk' , 'Ernestus Devote' , '1990/01/08' , 4 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('ivenn2p@hao123.com' , 'Idalia Venn' , '1990/01/17' , 5 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('bpalphramand2q@thetimes.co.uk' , 'Bar Palphramand' , '1991/12/15' , 5 , NULL, NULL)
INSERT INTO Customer (EmailId, Name, DateOfBirth, CreatedBy, ModifiedTimestamp, ModifiedBy) VALUES ('yspearman2r@mapquest.com' , 'Yvonne Spearman' , '1988/08/15' , 5 , NULL, NULL)
