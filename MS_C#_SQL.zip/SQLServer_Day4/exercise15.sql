CREATE function ufn_functionname(@BranchName varchar(50),@ActivationMode varchar(10))
RETURNS @result_table TABLE (AccountId int,AccountNumber varchar(15),balance money)
AS
BEGIN


	if @ActivationMode ='Active'
	begin
		insert @result_table
		SELECT AccountId,AccountNumber,balance FROM Account where branchid in (select branchid from branch where branchname=@Branchname) and isactive=1 
	end
	
	else if @ActivationMode = 'Inactive'
		insert @result_table
		SELECT AccountId,AccountNumber,balance FROM Account where branchid in (select branchid from branch where branchname=@Branchname) and isactive=0

return 
END

select * from ufn_functionname('Beberibe','Active')

select * from branch