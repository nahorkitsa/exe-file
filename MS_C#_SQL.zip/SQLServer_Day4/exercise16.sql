alter FUNCTION ufn_FetchIFSC(@BranchName VARCHAR(50))
RETURNS VARCHAR(11)
AS 
BEGIN
DECLARE @IFSC varCHAR(11)
SELECT @IFSC=IFSC FROM Branch WHERE BranchName=@BranchName
RETURN @IFSC
END

declare @res varchar(11)
exec @res=ufn_FetchIFSC 'Beberibe'
select @res as 'ifsc code'
