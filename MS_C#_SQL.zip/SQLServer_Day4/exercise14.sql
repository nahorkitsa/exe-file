 CREATE FUNCTION ufn_SearchCustomers(@name VARCHAR(100))
 RETURNS TABLE
 AS
 RETURN
	(SELECT * FROM Customer WHERE name=@name)
GO

select * from ufn_SearchCustomers('Tyne Vacher')

select * from Customer