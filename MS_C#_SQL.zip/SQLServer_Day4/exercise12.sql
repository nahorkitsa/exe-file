alter procedure usp_Transact
(
	@AccountNumber VARCHAR(15)  ,
	@Amount MONEY,
	@Type BIT,
	@Mode VARCHAR(20) ,
	@Remarks VARCHAR(30) ,
	@Info VARCHAR(200) ,
	@CreatedBy VARCHAR(50)
	
)
AS 
begin
	begin try
	begin tran

		declare @balance MONEY
		if not exists(select * from account where accountnumber = @accountnumber)
		begin
			return -1
		end
	
		if @amount<0
		begin
			return -2
		end
	
		if @type not in(0,1)
		begin
			return -3
		end
		
		if @type=1
		begin 
			--select 'here'
			set @mode = 'Bank-Credit'
		
			update account set balance = balance + @amount where accountnumber = @accountnumber
			--select 'here'
			insert into [transaction] values(@accountnumber,@amount,getdate(),@type,@mode,@remarks,@info,@createdby)
		end
		else if @type=0
		begin
			set @mode = 'Bank-Debit'
			select @balance = balance from	account where accountnumber = @accountnumber

			if @balance>@amount
			begin
				update account set balance = balance - @amount where accountnumber = @accountnumber
				insert into [transaction] values(@accountnumber,@amount,getdate(),@type,@mode,@remarks,@info,@createdby)
			end
		end 
	commit

	return 1

	end try
	
	begin catch
		return -99
	end catch
end
go


begin
declare @type bit = 1,@mode varchar(20),@remarks varchar(30)='NA',@info varchar(200)='NA',@createdby varchar(50)='NA'
declare @accountnumber varchar(15) = '007066100000001',@amount money = 5000,@res int 
exec @res = usp_Transact @accountnumber,@amount,@type,@mode,@remarks,@info,@createdby
select @res
end

select * from account
select * from [transaction]
