 CREATE FUNCTION ufn_GetBalance(@Accountno VARCHAR(100))
 RETURNS MONEY
 AS
 BEGIN
	declare @avail_bal money,@bal money ,@lockedbal money
	if EXISTS(SELECT* FROM account WHERE AccountNumber=@Accountno AND isactive=1)
 		begin
			SELECT @bal=balance,@lockedbal=lockedbalance FROM account
			@avail_bal=@bal-@lockedbal
		end
	else 
		@avail_bal=-1

return @avail_bal
END
GO

select * from ufn_SearchCustomers('Tyne Vacher')

select * from account