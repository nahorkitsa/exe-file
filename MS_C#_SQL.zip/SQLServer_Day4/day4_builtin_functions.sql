CREATE TABLE Student
(
	StudentId INT IDENTITY(1,1) CONSTRAINT pk_Student_StudentId PRIMARY KEY,
	StudentName VARCHAR(50) NOT NULL,
    Subject VARCHAR(50) NOT NULL,
	Marks INT NOT NULL CONSTRAINT chk_Student_Marks CHECK (Marks >= 0)
)
GO


INSERT INTO Student VALUES ('Monica', 'C#',  100)
INSERT INTO Student VALUES ('Phoebe', 'SQL server',  91)
INSERT INTO Student VALUES ('Rachel', 'C#', 82)
INSERT INTO Student VALUES ('Chandler', 'ADO.NET', 95)
INSERT INTO Student VALUES ('Joey', 'Entity framework', 77)
INSERT INTO Student VALUES ('Ross', 'C#', 86)
INSERT INTO Student VALUES ('Janice', 'SQL server', 99)
INSERT INTO Student VALUES ('Mark', 'C#', 86)
INSERT INTO Student VALUES ('David', 'ADO.NET', 75)
INSERT INTO Student VALUES ('Richard', 'C#' , 97)
INSERT INTO Student VALUES ('Emily', 'ADO.NET', 60)
INSERT INTO Student VALUES ('Julie', 'Entity framework', 65)
GO



SELECT StudentId, StudentName, [Subject], Marks, 
       ROW_NUMBER() OVER (ORDER BY Marks DESC) AS RowNo FROM Student

SELECT StudentId, StudentName, [Subject], Marks, 
	RANK() OVER (ORDER BY Marks DESC) AS Rank FROM Student

 SELECT StudentId, StudentName, [Subject], Marks, 
	      RANK() OVER (PARTITION BY [Subject] ORDER BY Marks DESC) 
	      AS Rank FROM Student 


SELECT StudentId, StudentName, [Subject], Marks, 
	      DENSE_RANK() OVER (ORDER BY Marks DESC) 
	      AS Rank FROM Student


SELECT StudentId, StudentName, [Subject], Marks, 
	     NTILE(7) OVER (ORDER BY Marks DESC) AS NTile5 FROM Student