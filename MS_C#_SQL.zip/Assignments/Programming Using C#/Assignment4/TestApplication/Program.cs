﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Assignment4;

namespace TestApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            //string[] document = new string[] { "Adhar Card", "Back" };

            //string[] document2 = { "Voter Card" };
            //Insurance obj = new Insurance("Raj", 6000, 18, document);
            //Insurance obj2 = new Insurance("Salony", document2);
            //Insurance obj3 = new Insurance("Rajan", 45, 90, document2);
            //string[] acceptableDocuments = { "Adhar Card", "Driving Licence", "Voter Card" };
            //if (obj.CheckDocuments(acceptableDocuments))
            //{
            //    Console.WriteLine("Dear" + " " + obj.consumerName + " " + "your policy has been approved with ID:" + " " + obj.insuranceId);

            //}
            //else
            //{
            //    Console.WriteLine("Not Approved");

            //}


            //if (obj2.CheckDocuments(acceptableDocuments))
            //{
            //    Console.WriteLine("Dear" + " " + obj2.consumerName + " " + "your policy has been approved with ID:" + " " + obj2.insuranceId);

            //}
            //else
            //{
            //    Console.WriteLine("Not Approved");

            //}


            //if (obj3.CheckDocuments(acceptableDocuments))
            //{
            //    Console.WriteLine("Dear" + " " + obj3.consumerName + " " + "your policy has been approved with ID:" + " " + obj3.insuranceId);

            //}
            //else
            //{
            //    Console.WriteLine("Not Approved");

            //}
        }
    }
}
