﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment4
{
    public class Insurance
    {
        private int age;
        private static int counter;
        private int creditHistory;
        private string[] documents;

        public string consumerName;
        public string insuranceId;

        #region Do Not Modify Signature     
        public Insurance()
        {
            this.age = 18;
            this.creditHistory = 45000;

        }
        #endregion

        static Insurance()
        {
            counter = 1000;
        }

        public Insurance(string consumerName):this()
        {
            this.consumerName = consumerName;
        }

        public Insurance(string consumerName,int creditHistory,int age,string[] documents):this(consumerName,documents)
        {
            this.age = age;
            this.creditHistory = creditHistory;
        }

        public Insurance(string consumerName,string[] documents):this(consumerName)
        {
            this.documents = documents;
        }

        public bool CheckEligibility()
        {
            if (this.age < 18)
            {
                return false;
            }
            else if (this.age > 18 && this.age <= 30 && this.creditHistory <= 60000)
            {
                return true;
            }
            else if (this.age > 30 && this.creditHistory <= 45000)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool CheckDocuments(string[] acceptabledocuments)
        {
            if (this.CheckEligibility())
            {
                foreach (var document in documents)
                {
                    foreach (var doc in acceptabledocuments)
                    {
                        if (doc == document)
                        {
                            insuranceId = "I" + counter.ToString();
                            counter++;
                            return true;
                        }
                    }

                }

            }

            return false;
        }
      
    }
}

