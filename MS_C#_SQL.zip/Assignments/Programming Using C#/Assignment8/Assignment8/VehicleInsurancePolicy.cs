﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment8
{
    public class VehicleInsurancePolicy:InsurancePolicy
    {
        public string VehicleCondition { get; set; }
        public double VehiclePrice { get; set; }
        public string VehicleType { get; set; }
        #region Do not modify
        public VehicleInsurancePolicy()
        { 
        }
        #endregion

        public VehicleInsurancePolicy(string vehicleType, double vehiclePrice, string vehicleCondition, int policyTerm) : base(policyTerm)
        {
            this.VehicleType = vehicleType;
            this.VehicleCondition = vehicleCondition;
            this.VehiclePrice = vehiclePrice;
        }
        public override double CalculatePolicyCover()
        {
            if (this.VehicleCondition == "New")
                PolicyCover = 0.9 * this.VehiclePrice;
            else if (this.VehicleCondition == "Good")
                PolicyCover = 0.75 * this.VehiclePrice;
            else if (this.VehicleCondition == "Old")
                PolicyCover = 0.5 * this.VehiclePrice;
            return PolicyCover;
        }

        public override double CalculateRisk()
        {
            double risk = 0;
            if (this.VehicleType == "Sports")
                risk += 0.35;
            else if (this.VehicleType == "Logistics")
                risk += 0.4;
            else if (this.VehicleType == "Sedan")
                risk += 0.2;
            else
                risk += 0.15;
            return risk;
        }
    }
}
