﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment8
{
    public class LifeInsurancePolicy:InsurancePolicy
    {
        public int Age { get; set; }
        public string MedicalHistory { get; set; }
        #region Do not modify

        public LifeInsurancePolicy()
        {

        }

        #endregion
        public LifeInsurancePolicy(int age, string medicalHistory, double policyCover, int policyTerm) : base(policyTerm)
        {
            this.Age = age;
            this.MedicalHistory = medicalHistory;
            base.PolicyCover = policyCover;
        }

        public override double CalculatePolicyCover()
        {
            return this.PolicyCover;
        }

        public override double CalculateRisk()
        {
            double risk = 0;
            if (this.Age <= 25)
                risk += 0.05;
            else if (this.Age <= 40)
                risk += 0.1;
            else if (this.Age <= 55)
                risk += 0.15;
            else
                risk += 0.2;

            if (this.MedicalHistory == "Clear")
                risk += 0.05;
            else if (this.MedicalHistory == "Minor")
                risk += 0.1;
            else if (this.MedicalHistory == "Moderate")
                risk += 0.15;
            else if (this.MedicalHistory == "Major")
                risk += 0.2;

            return risk;
        }
    }
}
