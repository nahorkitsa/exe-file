﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment8
{
    public abstract class InsurancePolicy
    {

        public double PolicyCover { get; set; }
        public int PolicyTerm { get; set; }
        public double Premium { get; set; }
        public double Risk { get; set; }

        #region Do not modify
        public InsurancePolicy()
        {

        }
        #endregion

        public InsurancePolicy(int policyTerm)
        {
            PolicyTerm = policyTerm;

        }

        public abstract double CalculatePolicyCover();
        

        public double CalculatePremium()
        {
            return this.CalculatePolicyCover() * this.CalculateRisk() / this.PolicyTerm;
        }

        public abstract double CalculateRisk();
       
     }

}
