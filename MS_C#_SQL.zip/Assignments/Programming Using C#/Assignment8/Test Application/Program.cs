﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Assignment8;

namespace TestApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            //LifeInsurancePolicy lifeInsurancePolicy;

            //lifeInsurancePolicy = new LifeInsurancePolicy(35, "Minor", 1000000, 60);
            //lifeInsurancePolicy.CalculatePremium();
            //Console.WriteLine("The monthly premium to be paid is: " + lifeInsurancePolicy.Premium);

            //lifeInsurancePolicy = new LifeInsurancePolicy(50, "Minor", 500000, 120);
            //lifeInsurancePolicy.CalculatePremium();
            //Console.WriteLine("The monthly premium to be paid is: " + lifeInsurancePolicy.Premium);

            //lifeInsurancePolicy = new LifeInsurancePolicy(56, "Major", 300000, 120);
            //lifeInsurancePolicy.CalculatePremium();
            //Console.WriteLine("The monthly premium to be paid is: " + lifeInsurancePolicy.Premium);

            //VehicleInsurancePolicy vehicleInsurancePolicy = new VehicleInsurancePolicy("Sports", 1000000, "New", 120);
            //vehicleInsurancePolicy.CalculatePremium();
            //Console.WriteLine("The monthly premium to be paid is: " + vehicleInsurancePolicy.Premium);

            //vehicleInsurancePolicy = new VehicleInsurancePolicy("Hatchback", 700000, "Old", 60);
            //vehicleInsurancePolicy.CalculatePremium();
            //Console.WriteLine("The monthly premium to be paid is: " + vehicleInsurancePolicy.Premium);

        }
    }
}
