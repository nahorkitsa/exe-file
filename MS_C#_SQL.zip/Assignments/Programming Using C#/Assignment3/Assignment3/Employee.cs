﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3
{
    public class Employee
    {
        private DateTime dateOfBirth;
        private string[] dependents;
        private int employeeId;
        private string employeeName;
        private bool gender;
        private static int nextEmployeeNumber;
        private short numberOfDependents;

        #region Do Not Modify Signature
        static Employee()
        {
            Employee.nextEmployeeNumber = 1001;
        }

        public Employee()
        {
            this.employeeId = Employee.nextEmployeeNumber;
            Employee.nextEmployeeNumber += 1;
            this.dependents = new string[3];
        }

       

        public Employee(string employeeName,DateTime dateOfBirth,bool gender):this()
        {
            this.employeeName = employeeName;
            this.dateOfBirth = dateOfBirth;
            this.gender = gender;
        }

        public Employee(string employeeName, DateTime dateOfBirth, bool gender, short numberOfDependents) : this(employeeName, dateOfBirth, gender)
        {
            if (numberOfDependents <= 0)
            {
                this.numberOfDependents = 0;
            }
            else if (numberOfDependents > 3)
            {
                this.numberOfDependents = 3;
            }
            else
            {
                this.numberOfDependents = numberOfDependents;
            }
        }

        public int AddDependent(string dependantName)
        {
            if (this.numberOfDependents == 3)
            {
                return 0;
            }
            else
            {
                for (int i = 0; i < dependents.Length; i++)
                {
                    if (dependents[i] == null)
                    {
                        dependents[i] = dependantName;
                        this.numberOfDependents += 1;
                        break;
                    }
                }
                return numberOfDependents;

            }
        }
        public bool UpdateDependents(string dependentName, int dependentId)
        {

            if (dependentId <= numberOfDependents && dependentId >0)
            {
                this.dependents[dependentId - 1] = dependentName;
                return true;
            }
            else
            {
                return false;
            }

        }
        #endregion
    }
}
