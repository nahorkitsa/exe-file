﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Assignment3;

namespace TestApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            //Employee emp1 = new Employee("Javier", new DateTime(1975, 5, 4), false, 2);

            //Console.WriteLine("Called Update 1: " + emp1.UpdateDependents("Kathy", 1));
            //Console.WriteLine("Called Update 2: " + emp1.UpdateDependents("Jim", 2));
            //Console.WriteLine("Called Update 3: " + emp1.UpdateDependents("Dorothy", 3));

            //Console.WriteLine("Called Add 1: " + emp1.AddDependent("Dorothy"));
            //Console.WriteLine("Called Add 2: " + emp1.AddDependent("Rony"));
            //Console.ReadLine();
        }
    }
}
