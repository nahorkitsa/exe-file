﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{
    public class Instructor
    {
        private float avgFeedback;
        private int experience;
        private string instructorName;
        private string[] instructorSkill;

        #region Do Not Modify
        public Instructor()
        {

        }

        public Instructor(string instructorName,float avgFeedback,int experience,string[] instructorSkill)
        {
            this.instructorName = instructorName;
            this.avgFeedback = avgFeedback;
            this.experience = experience;
            this.instructorSkill = instructorSkill;
        }

        public bool ValidateEligibility()
        {
            if (this.experience > 3 && this.avgFeedback >= 4.5)
            {
                return true;
            }
            else if (this.experience <= 3 && this.avgFeedback >= 4)
            {
                return true;
            }
            else
            {
                return false;
            }
            
        }


        public bool CheckSkill(string technology) 
        {
            for (int i = 0; i < this.instructorSkill.Length; i++)
            {
                if (instructorSkill[i] == technology && this.ValidateEligibility())
                {
                    return true;
                } 
            }
            return false;

        }


        #endregion

    }
}
