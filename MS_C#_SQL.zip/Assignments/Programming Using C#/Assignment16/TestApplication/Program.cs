﻿using Assignment16;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            //Bill billObj = new Bill("B1001", 2, 1000);
            //Restaurant restaurantObj = new Restaurant();

            //Console.WriteLine("Bill Id:" + billObj.BillId);
            //Console.WriteLine("Total Bill Amount: " + restaurantObj.CalculateAmount(billObj));


        }
    }
}
