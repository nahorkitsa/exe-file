﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment16
{
   public class Restaurant
   {
       #region Do Not Modify
       public Restaurant()
        {

        }
        #endregion

        public double CalculateAmount(Bill billObj)
        {
            double total_amount = billObj.Quantity * billObj.Price;
            double service_tax=billObj.CalculateServiceTax(billObj.Quantity * billObj.Price);
            return total_amount + service_tax;
        }
   }
}
