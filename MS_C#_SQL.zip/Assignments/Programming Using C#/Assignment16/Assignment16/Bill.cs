﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment16
{
    public class Bill
    {
        public string BillId { get; set; }
        public double Price { get; set; }
        public int Quantity { get; set; }
        #region Do Not Modify
        public Bill()
        {

        }
        #endregion


        public Bill(string billId, int quantity, double price)
        {
            BillId = billId;
            Quantity = quantity;
            Price = price;  
        }
    }
}
