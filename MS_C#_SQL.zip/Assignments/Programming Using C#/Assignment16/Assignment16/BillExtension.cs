﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment16
{
    public static class BillExtension
    {
        #region Do Not Modify
        static BillExtension()
        {

        }
        #endregion
        public static double CalculateServiceTax(this Bill obj, double totalAmount)
        {

            if (totalAmount < 2000)
            {
                return 0;
            }

            else if (totalAmount >= 2000 && totalAmount <= 5000)
            {
                return (totalAmount * 0.02);
            }

            else if (totalAmount > 5000)
            {
                return  (totalAmount * 0.05);
            }

            return 0;
            
        }

     
    }
}
