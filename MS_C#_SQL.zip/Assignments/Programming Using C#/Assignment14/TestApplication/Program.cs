﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Assignment14;

namespace TestApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            //Claim claims1 = new Claim(1, 2, 3);
            //Assistant assObj1 = new Assistant();
            //assObj1.ApproveClaim("InsuranceManager", ref claims1);
            //Console.WriteLine("Claim Id:" + claims1.ClaimId);
            //Console.WriteLine("Status by Under Writer:" + claims1.CommentUW);
            //Console.WriteLine("Status by Bank Manager:" + claims1.CommentBM);


            //Claim claims2 = new Claim(2, 2, 4);
            //Assistant assObj2 = new Assistant();
            //assObj2.ApproveClaim("InsuranceManager", ref claims2);
            //Console.WriteLine("Claim Id:" + claims2.ClaimId);
            //Console.WriteLine("Status by Under Writer:" + claims2.CommentUW);
            //Console.WriteLine("Status by Bank Manager:" + claims2.CommentBM);

            //Console.ReadLine();
        }
    }
}
