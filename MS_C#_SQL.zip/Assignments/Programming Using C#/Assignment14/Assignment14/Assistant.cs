﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment14
{
    public class Assistant
    {

        

        #region Do not modify region
        public Assistant()
        { }
        #endregion

        public void ApproveClaim(string role, ref Claim claims)
        {
            ApproveClaimDelegate del_obj;
            if (role == "UnderWriter")
            {
                del_obj = claims.ApproveClaimUW;
                del_obj.Invoke(ref claims);

            }
            else if (role == "BankManager")
            {
                del_obj = claims.ApproveClaimBM;
                del_obj.Invoke(ref claims);

            }
            else if (role == "InsuranceManager")
            {
                del_obj = claims.ApproveClaimUW;
                del_obj +=claims.ApproveClaimBM;
                del_obj.Invoke(ref claims);
            }

        }

    }    
    
}
