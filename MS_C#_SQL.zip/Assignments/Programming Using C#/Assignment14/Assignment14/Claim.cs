﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment14
{

    public delegate void ApproveClaimDelegate(ref Claim claims);
    public class Claim
    {
        public int ClaimId { get; set; }
        public string CommentBM { get; set; }
        public string CommentUW { get; set; }
        public int NoOfProofs { get; set; }
        public int InsuranceId { get; set; }
        #region Do not modify region
        public Claim()
        {

        }
        #endregion

        public Claim(int claimId,int insuranceId,int noOfProofs)
        {
            this.ClaimId = claimId;
            this.InsuranceId = insuranceId;
            this.NoOfProofs = noOfProofs;
        }

        public void ApproveClaimBM(ref Claim claim)
        {
            if (claim.CommentUW == "Approved")
            {
                claim.CommentBM = "Approved";

            }
            else if (claim.CommentUW == "Rejected")
            {
                claim.CommentBM = "Rejected";
            }

            else
            {
                claim.CommentBM = "NA";
            }
        }

        public void ApproveClaimUW(ref Claim claim)
        {
            if (claim.NoOfProofs >= 3)
            {
                claim.CommentUW = "Approved";
            }
            else
            {
                claim.CommentUW = "Rejected";
            }
        }
    }
    }

