﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment13
{
    public class Calculation
    {
        public int PerformCalculation(int choice,int numberOne,int numberTwo)
        {
            CalculatorDelegate del_obj;
            Calculator calc = new Calculator();
            switch (choice)
            {
                case 1:
                    {
                        del_obj = calc.Add;
                        return del_obj.Invoke(numberOne, numberTwo);
                    }

                case 2:
                    {
                        del_obj = calc.Subtract;
                        return del_obj.Invoke(numberOne, numberTwo);
                    }

                case 3:
                    {
                        del_obj = calc.Multiply;
                        return del_obj.Invoke(numberOne, numberTwo);
                    }

                default:
                    {
                        del_obj = calc.Add;
                        return del_obj.Invoke(numberOne, numberTwo);
                    }
            }
            
        }
    }
}
