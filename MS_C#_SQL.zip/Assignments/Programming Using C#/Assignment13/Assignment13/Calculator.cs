﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment13
{

    public delegate int CalculatorDelegate(int n1, int n2);
    public class Calculator
    {
    
        public int Add(int numberOne,int numberTwo)
        {
            return numberOne+numberTwo;    
        }

        public int Subtract(int numberOne, int numberTwo)
        {
            return numberOne-numberTwo;
        }

        public int Multiply(int numberOne, int numberTwo)
        {
            return numberOne*numberTwo;
        }

    }


}
