﻿using Assignment13;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            //Calculation calculation = new Calculation();
            //Console.WriteLine("The two numbers are 9 and 17");
            //int result = calculation.PerformCalculation(1, 9, 17);
            //Console.WriteLine("Result when choice is 1 : " + result);
            //result = calculation.PerformCalculation(2, 17, 9);
            //Console.WriteLine("Result when choice is 2 : " + result);
            //result = calculation.PerformCalculation(3, 17, 9);
            //Console.WriteLine("Result when choice is 3 : " + result);
            //result = calculation.PerformCalculation(4, 9, 17);
            //Console.WriteLine("Result when choice is neither 1, nor 2 nor 3 : " + result);
        }
    }
}
