﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Assignment2;

namespace TestApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            //string[] payees = { "Parveen", "Ratul" };
            //long[] payeesAccount = { 78906210000, 54326720000 };
            //Account bankObj = new Account(34562789652, 50000, payees, payeesAccount);
            //int result = bankObj.TransferMoney("Parveen", 1000);
            //if (result == 1)
            //{
            //    Console.WriteLine("Balance in account after transaction: " + bankObj.balance);
            //}
            //else if (result == -1)
            //{
            //    Console.WriteLine("Account details are not present");
            //}
            //else if (result == 0)
            //{
            //    Console.WriteLine("Balance in account is not sufficient");
            //}
            //else
            //{
            //    Console.WriteLine("Transaction failed due to some error. Try after some time");
            //}


            //int result1 = bankObj.TransferMoney(54326720000, 51000);
            //if (result1 == 1)
            //{
            //    Console.WriteLine("Balance in account after transaction: " + bankObj.balance);
            //}
            //else if (result1 == -1)
            //{
            //    Console.WriteLine("Account details are not present");
            //}
            //else if (result1 == 0)
            //{
            //    Console.WriteLine("Balance in account is not sufficient");
            //}
            //else
            //{
            //    Console.WriteLine("Transaction failed due to some error. Try after some time");
            //}


            Console.ReadLine();
        }
    }
}
