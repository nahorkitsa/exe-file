﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2
{
    public class Account
    {
        #region Do not modify
        public string[] payees;
        public long[] payeesAccount;
        public long accountNo;
        public double balance;

        public Account()
        {
            payees = new string[10];
            payeesAccount = new long[10];
        }

        public Account(long accountNo,double balance)
        {
            this.accountNo = accountNo;
            this.balance = balance;
        }

        public Account(long accountNo,double balance,string[] payees,long[] payeesAccount):this(accountNo,balance)
        {
            this.payees = payees;
            this.payeesAccount = payeesAccount;
        }

        public int DebitAmount(double amount)
        {
            if (amount <= this.balance)
            {
                this.balance -=amount;
                return 1;
            }
            return 0;
        }

        public int TransferMoney(long payeeAccountNo,double amount)
        {
            for(int i=0;i<this.payeesAccount.Length ;i++)
            {
                if (this.payeesAccount[i] == payeeAccountNo)
                {
                    int result = this.DebitAmount(amount);
                    return result;
                }
            }
            
            return -1;
        }

        public int TransferMoney(string nickName, double amount)
        {
            for (int i = 0; i < this.payees.Length; i++)
            {
                if (this.payees[i] == nickName)
                {
                    int result = this.DebitAmount(amount);
                    return result;
                }
            }

            return -1;
        }

        #endregion
    }
}
