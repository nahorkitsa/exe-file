﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment9
{
    public class Bill
    {
        #region Do not modify
        public Bill()
        {

        }
        #endregion

        public double GenerateBill(Patient obj)
        {
            if (obj is Inpatient)
            {
                return ((Inpatient)obj).CalculateConsultationFee() + ((Inpatient)obj).RoomCharge();
            }
            else if (obj is Outpatient)
            {
                return ((Outpatient)obj).CalculateConsultationFee();
            }
            else
            {
                return 0.00;
            }
        }
    }
}
