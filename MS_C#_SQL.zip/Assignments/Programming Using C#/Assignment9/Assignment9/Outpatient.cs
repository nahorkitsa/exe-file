﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment9
{
    public class Outpatient : Patient
    {
        #region Do not modify
        public Outpatient()
        {

        }
        #endregion

        public Outpatient(string name, int age, char gender, string illness):base(name,age,gender,illness)
        {
        }

        public override double CalculateConsultationFee()
        {
            if (Illness == "Cough" || Illness == "Fever")
            {
                return base.CalculateConsultationFee() - 10;
            }
            else
            {
                return base.CalculateConsultationFee() + 10;
            }

        }

    }
}
