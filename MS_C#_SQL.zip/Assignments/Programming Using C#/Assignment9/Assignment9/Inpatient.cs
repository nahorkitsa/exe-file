﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment9
{
    public class Inpatient : Patient
    {
        private int days;
        public int Days {
            get { return days; }
            
            set
            {
                if (value > 0)
                {
                    days = value;
                }
                else
                {
                    days = 1;
                }
            }
        }
        public double ExtraService { get; set; }
        public double PerDayService { get; set; }
        

        #region Do not modify
        public Inpatient()
        {

        }
        #endregion

        public Inpatient(string name, int age, char gender, string illness, int days):base(name,age,gender,illness)
        {
            Days = days;
            PerDayService = 155.50;
            ExtraService = 100;
        }

        public override double CalculateConsultationFee()
        {
            double result=base.CalculateConsultationFee();
            return result + ExtraService;
        }

        public double RoomCharge()
        {
            if (days <= 7)
            {
                return days * PerDayService;
            }
            else if (days > 7)
            {
                return (days * PerDayService +days *ExtraService);
            }

            return 0;
        }
    }
}
