﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment9
{
   

    public class Patient
    {
        public int Age { get; set; }
        public double ConsultationFee { get; set; }
        public char Gender { get; set; }
        public string Illness { get; set; }
        public string Name { get; set; }


        #region Do not modify
        public Patient()
        {

        }
        #endregion

        public Patient(string name, int age, char gender, string illness)
        {
            this.Name = name;
            this.Age = age;
            this.Gender = gender;
            this.Illness = illness;

        }

        public virtual double CalculateConsultationFee()
        {
            double cfee = 0;
            if (this.Age > 0 && this.Age <= 18)
            {
                cfee= this.Age * 10;
            }
            else if (this.Age > 18)
            {
               cfee= this.Age * 15;
            }
            this.ConsultationFee = cfee;
            return cfee;
        }
    }
}
