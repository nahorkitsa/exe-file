﻿using Assignment9;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            //Bill bill = new Bill();
            ////Patient patient = new Patient("John", 21, 'M', "Hairline Fracture");
            //Inpatient inpatient = new Inpatient("John", 21, 'M', "Hairline Fracture", 5);
            //Console.WriteLine("Inpatient John:" + bill.GenerateBill(inpatient));

            //Outpatient outpatient = new Outpatient("Smith", 25, 'M', "Fever");
            //Console.WriteLine("Outpatient Smith:" + bill.GenerateBill(outpatient));

            //Patient patientIn = new Inpatient("Elena", 35, 'F', "Multiple Fracture", 15);
            //Console.WriteLine("Patient ref to Inpatient Elena:" + bill.GenerateBill(patientIn as Inpatient));

            //Patient patientOut = new Outpatient("Rosalind", 35, 'F', "Eye Irritation");
            //Console.WriteLine("Patient ref to Outpatient Rosalind:" + bill.GenerateBill(patientOut as Outpatient));
            //Console.Read();
        }
    }
}
