﻿using Assignment11;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            //HealthClub healthClub = new HealthClub();
            //healthClub.AddEmployee("E001");
            //healthClub.AddEmployee("E002");
            //Console.WriteLine("List of registered employees after adding employees");
            //Console.WriteLine("---------------------------------------------------------------");
            //foreach (string employeeId in healthClub.EmployeeIdList)
            //    Console.WriteLine(employeeId);
            //Console.WriteLine();

            //bool deleteStatus = healthClub.DeleteEmployee("E001");
            //if (deleteStatus)
            //    Console.WriteLine("EmployeeId - E001 has been deleted");
            //else Console.WriteLine("EmployeeId - E001 has not been deleted");
            //Console.WriteLine("List of currently registered employees");
            //Console.WriteLine("---------------------------------------------------------------");
            //foreach (string employeeId in healthClub.EmployeeIdList)
            //    Console.WriteLine(employeeId);
            //Console.WriteLine();

            //deleteStatus = healthClub.DeleteEmployee("E003");
            //if (deleteStatus)
            //    Console.WriteLine("EmployeeId - E003 has been deleted");
            //else Console.WriteLine("EmployeeId - E003 has not been deleted");
            //Console.WriteLine("List of currently registered employees");
            //Console.WriteLine("---------------------------------------------------------------");
            //foreach (string employeeId in healthClub.EmployeeIdList)
            //    Console.WriteLine(employeeId);
        }
    }
}
