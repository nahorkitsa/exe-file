﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment11
{
    public class HealthClub
    {
        private List<string> employeeIdList;
        public List<string> EmployeeIdList { get { return employeeIdList; }
            set
            {
                employeeIdList = value;
            }
        } 
        public void AddEmployee(string employeeId)
        {
            if (employeeIdList == null)
            {
                EmployeeIdList = new List<string>();
            }
            EmployeeIdList.Add(employeeId);
        }

        public bool DeleteEmployee(string employeeId)
        {
            if (EmployeeIdList.Contains(employeeId))
            {
                EmployeeIdList.Remove(employeeId);
                return true;
            }
            else
            {
                return false;
            }

        }

    }
}
