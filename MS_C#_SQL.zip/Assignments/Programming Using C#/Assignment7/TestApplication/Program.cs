﻿using Assignment7;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            //string[] testId = { "L1", "L2" };
            //Patient obj = new Patient(1000, "John", testId);
            //Console.WriteLine(obj.CalculateCharge());
        }
    }
}
