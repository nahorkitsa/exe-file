﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment7
{
   public class LabTestRepository
   {
        
       #region Do Not Modify
       private string[] labTestId = new string[4];
        private double[] labTestCharge = new double[4];
       #endregion

        #region Do Not Modify the Signature
        public LabTestRepository()
        {
            labTestId[0] = "L1";
            labTestId[1] = "L2";
            labTestId[2] = "L3";
            labTestId[3] = "L4";

            labTestCharge[0] = 500;
            labTestCharge[1] = 200;
            labTestCharge[2] = 700;
            labTestCharge[3] = 900;


        }
        #endregion

        public double GetCharge(string testId)
        {
            for (int i = 0; i < labTestId.Length; i++)
            {
                if (labTestId[i] == testId)
                {
                    return labTestCharge[i];
                }
            }

            return 0;
        }
        
    }
}
