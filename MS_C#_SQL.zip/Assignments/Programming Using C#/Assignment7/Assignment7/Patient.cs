﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment7
{
    public class Patient
    {

        private string[] labTestId;
        private int patientId;
        private string patientName;

        #region Do Not Modify
        public Patient()
        {

        }
        #endregion

        public Patient(int patientId,string patientName,string[] labTestId)
        {
            this.patientId = patientId;
            this.patientName = patientName;
            this.labTestId = labTestId;
        }

        public double CalculateCharge()
        {
            double totalCharge=0;
            LabTestRepository l = new LabTestRepository();
            for (int i = 0; i < labTestId.Length; i++)
            {
                totalCharge += l.GetCharge(labTestId[i]);
            }
            return totalCharge;
        }

    }
}
