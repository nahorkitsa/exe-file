﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment12
{

    public delegate void GetBonus(double amount);

    public class BankAccount
    {
        private double balance;
        public double Balance { get { return balance; } set { balance = value; } }


        public void Credit(double amount)
        {
            Balance += amount;
        }

        public bool Debit(double amount)
        {
            if (amount <= Balance)
            {
                Balance -= amount;
                return true;
            }
            return false;
        }
    }
}
