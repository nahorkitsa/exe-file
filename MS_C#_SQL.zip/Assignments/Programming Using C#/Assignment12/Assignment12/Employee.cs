﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment12
{

    public class Employee
    {
        private BankAccount account;
        private int numberOfShares;
        private double pensionFundBalance;

        public BankAccount Account { get { return account; } set { account = value; } }
        public int NumberOfShares { get { return numberOfShares; } set { numberOfShares = value; } }
        public double PensionFundBalance { get {return pensionFundBalance; } set {pensionFundBalance=value; } }

        public void GiveBonus(int bonusOption,double amount)
        {
            if (bonusOption == 1)
            {
                GetBonus del_obj = SetBankAccountCredit;
                del_obj.Invoke(amount);
            }

            else if (bonusOption == 2)
            {
                GetBonus del_obj = SetPensionFundCredit;
                del_obj.Invoke(amount);
            }

            else if (bonusOption == 3)
            {
                GetBonus del_obj = SetNumberOfShares;
                del_obj.Invoke(amount);
            }
            else
            {
                GetBonus del_obj = SetBankAccountCredit;
                del_obj.Invoke(amount);
            }
        }

        public void SetBankAccountCredit(double amount)
        {
            Account.Credit(amount);
        }

        public void SetNumberOfShares(double amount)
        {
            NumberOfShares += (int)(amount / 100);
        }
        public void SetPensionFundCredit(double amount)
        {
            PensionFundBalance += amount;
        }



    }
}
