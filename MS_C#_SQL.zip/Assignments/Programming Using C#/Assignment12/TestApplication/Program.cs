﻿using Assignment12;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            //Employee employeeOne = new Employee();
            //BankAccount bankAccountOne = new BankAccount();
            //bankAccountOne.Balance = 200000;
            //employeeOne.Account = bankAccountOne;
            //Console.WriteLine("Balance of employeeOne before bonus : " + employeeOne.Account.Balance);
            //employeeOne.GiveBonus(1, 2000);
            //Console.WriteLine("Balance of employeeOne after bonus : " + employeeOne.Account.Balance);
            //Console.WriteLine();

            //Employee employeeTwo = new Employee();
            //employeeTwo.PensionFundBalance = 200000;
            //Console.WriteLine("Pension Fund Balance of employeeTwo before bonus : " + employeeTwo.PensionFundBalance);
            //employeeTwo.GiveBonus(2, 2000);
            //Console.WriteLine("Pension Fund Balance of employeeTwo after bonus : " + employeeTwo.PensionFundBalance);
            //Console.WriteLine();

            //Employee employeeThree = new Employee();
            //employeeThree.NumberOfShares = 200;
            //Console.WriteLine("Number of shares of employeeThree before bonus : " + employeeThree.NumberOfShares);
            //employeeThree.GiveBonus(3, 2000);
            //Console.WriteLine("Number of shares of employeeThree after bonus : " + employeeThree.NumberOfShares);
            //Console.WriteLine();

            //Employee employeeFour = new Employee();
            //BankAccount bankAccountFour = new BankAccount();
            //bankAccountFour.Balance = 200000;
            //employeeFour.Account = bankAccountFour;
            //Console.WriteLine("Balance of employeeFour before bonus : " + employeeFour.Account.Balance);
            //employeeFour.GiveBonus(4, 2000);
            //Console.WriteLine("Balance of employeeFour after bonus : " + employeeFour.Account.Balance);


        }
    }
}
