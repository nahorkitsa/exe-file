﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Assignment15;

namespace TestApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            Interview interview = new Interview("", "system engineer", "http://google.com/this-is a sample portfolio", "Interviewer is very nice.technically strong also.", 23, 9876786566);

            Console.WriteLine("------------------------Details for interviewee---------------------");
            Console.WriteLine("Name:" + interview.Name);
            Console.WriteLine("Age:" + interview.Age);
            Console.WriteLine("Contact Number:" + interview.PhoneNumber);
            Console.WriteLine("Profile: " + interview.JobProfile);
            Console.WriteLine("Portfolio URL: " + interview.PortfolioUrl);
            Console.WriteLine("Suggestion: " + interview.Suggestion);

        }
    }
}
