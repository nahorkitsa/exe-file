﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment15
{
    public static class Formatter
    {
        #region Do Not Modify
        static Formatter()
        {

        }
        #endregion

        public static string CapitalizeLetter(this string value)
        {
            if (!String.IsNullOrEmpty(value))
            {
                bool flag = false;
                string s = value.ToLower();
                string newString = Char.ToUpper(s[0]).ToString();
                int count = 1;

                foreach (var c in s)
                {
                    if (count == 1)
                    {
                        count++;
                        continue;
                    }

                    if (flag == true)
                    {
                        if (c.Equals(' ') || c.Equals('.'))
                        {
                            newString += c;
                            continue;
                        }
                        newString += Char.ToUpper(c);
                        flag = false;
                        continue;
                    }
                    if (c.Equals(' ') || c.Equals('.'))
                    {
                        flag = true;
                        newString += c;
                    }
                    else
                    {
                        newString += c;
                        flag = false;
                    }

                }
                return newString;
            }
            else
            {
                return value;
            }
        }

        public static string UrlEncode(this string input)
        {

            return input.Replace(" ","%20");
        }
    }
}
