﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment15
{
    public class Interview
    {

        public int Age { get; set; }
        public string JobProfile { get; set; }
        public string Name { get; set; }
        public long PhoneNumber { get; set; }
        public string PortfolioUrl { get; set; }
        public string Suggestion { get; set; }

        #region Do Not Modify
        public Interview()
        {

        }
        #endregion

        public Interview(string name, string jobProfile, string portfolioUrl, string suggestion, int age, long phoneNumber)
        {
            Name = name.CapitalizeLetter();
            JobProfile = jobProfile.CapitalizeLetter();
            Age = Convert.ToInt32(age.ToString().CapitalizeLetter());
            PortfolioUrl = portfolioUrl.UrlEncode();
            PhoneNumber = phoneNumber;

            Suggestion = suggestion;

        }
    }
}
