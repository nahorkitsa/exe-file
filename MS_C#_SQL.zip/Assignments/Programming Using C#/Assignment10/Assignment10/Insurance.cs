﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment10
{
    
    public class Insurance
    {
        public string InsuranceId { get; set; }
        public string InsuranceName { get; set; }
        public double InsurancePolicyAmount { get; set; }
        public double InsurancePremium { get; set; }
        public int InsuranceTerm { get; set; }


        #region Do Not Modify
        public Insurance()
        {

        }
        #endregion

        public Insurance(string insuranceId, string insuranceName, int insuranceTerm, double amount, double premium)
        {
            this.InsuranceId = insuranceId;
            this.InsuranceName = insuranceName;
            this.InsuranceTerm = insuranceTerm;
            this.InsurancePolicyAmount = amount;
            this.InsurancePremium = premium;

        }
	
    }
   
}
