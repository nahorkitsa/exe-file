﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment10
{


    public class Agent
    {
        public List<Insurance> InsuranceList { get; set; }


        public List<Insurance> AddPolicy(Insurance obj)
        {
            if (InsuranceList == null)
            {
                InsuranceList = new List<Insurance>();
                InsuranceList.Add(obj);
            }
            else
            {
                Insurance ins = SearchPolicy(obj.InsuranceId);
                if ( ins != null)
                {

                }
                else
                {
                    InsuranceList.Add(obj);
                }
            }
            return InsuranceList;

        }


        public List<Insurance> DeletePolicy(string insuranceId)
        {
        
                InsuranceList.Remove(this.SearchPolicy(insuranceId));
                return InsuranceList;
        
        }

        public Insurance SearchPolicy(string insuranceId)
        {

            foreach (var insurance_obj in InsuranceList)
            {
                if (insuranceId == insurance_obj.InsuranceId)
                {
                    return insurance_obj;
                }
                
            }
            return null;

        }
    }
}
