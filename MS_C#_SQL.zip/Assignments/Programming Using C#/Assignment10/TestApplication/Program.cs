﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Assignment10;

namespace TestApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            Insurance insurance1 = new Insurance("I101", "LifeInsurance", 5, 1000, 50000);
            Insurance insurance2 = new Insurance("I102", "HealthInsurance", 2, 2000, 60000);
            Insurance insurance3 = new Insurance("I103", "MedicalInsurance", 3, 3000, 20000);
            Insurance insurance4 = new Insurance("I104", "AccidentalInsurance", 1, 4000, 100000);
            Agent bank = new Agent();

            List<Insurance> list = bank.AddPolicy(insurance1);
            List<Insurance> list1 = bank.AddPolicy(insurance2);
            Console.WriteLine("*** Adding Policy ***");
            if (list != null && list1 != null)
            {
                foreach (Insurance value in list)
                {

                    Console.WriteLine("Insurance id:" + value.InsuranceId);
                    Console.WriteLine("Insurance Name:" + value.InsuranceName);
                    Console.WriteLine("Insurance Term Period:" + value.InsuranceTerm);
                    Console.WriteLine("Insurance amount:" + value.InsurancePolicyAmount);
                    Console.WriteLine("Insurance premium: " + value.InsurancePremium);
                    Console.WriteLine("*** End ***");
                }
            }
            else
                Console.WriteLine("Insurance list is empty!!!");
            Console.WriteLine("*** Search Policy ***");
            bank.SearchPolicy(insurance1.InsuranceId);
            Console.WriteLine("Searched Insurance Name:" + insurance1.InsuranceName);
            Console.WriteLine("*** Delete Existing Policy ***");
            bank.DeletePolicy(insurance1.InsuranceId);
            Console.WriteLine("Insurance Successfully removed!!!");
            Console.WriteLine("*** After Deleting Existing Policy ***");
            if (list != null)
            {
                foreach (Insurance value in list)
                {

                    Console.WriteLine("Insurance id:" + value.InsuranceId);
                    Console.WriteLine("Insurance Name:" + value.InsuranceName);
                    Console.WriteLine("Insurance Term Period:" + value.InsuranceTerm);
                    Console.WriteLine("Insurance amount:" + value.InsurancePolicyAmount);
                    Console.WriteLine("Insurance premium: " + value.InsurancePremium);
                    Console.WriteLine("*** End ***");
                }

            }
        }
    }
}
