﻿using Assignment6;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            //Bus busObj = new Bus(5, 100, 1234);
            //Console.WriteLine("The total fare in bus is "+ busObj.CalculateTotalFare());

            //Cab cabObj = new Cab(10, 100, "VDER", 5634);
            //Console.WriteLine("The total fare in cab is " + cabObj.CalculateTotalFare());
        }
    }
}
