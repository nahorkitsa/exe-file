﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment6
{
   public class Cab:Vehicle
   {
        private string voucher;

       #region Do Not Modify
       public Cab()
        {

        }
        #endregion

        public Cab(double farePerKM, int distance,string voucher, int vehicleNumber):base(farePerKM,distance)
        {
            this.voucher = voucher;
            this.vehicleId = "C" + vehicleNumber.ToString();
        }

        public override double CalculateTotalFare()
        {
            double totalFare =base.CalculateTotalFare();
            double tax = totalFare * 0.05;
            if (this.voucher != null)
            {
                totalFare -= 100;
                totalFare += totalFare*0.05;
                return totalFare;
            }
            totalFare = totalFare + tax;
            return totalFare;

        }

    }
}
