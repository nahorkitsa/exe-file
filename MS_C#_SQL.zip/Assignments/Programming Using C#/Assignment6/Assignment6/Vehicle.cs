﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment6
{
   public class Vehicle
   {
        private int distance;
        private double farePerKM;
        protected string vehicleId;

       #region Do Not Modify
       public Vehicle()
        {

        }
        #endregion

        public Vehicle(double farePerKM,int distance)
        {
            this.distance = distance;
            this.farePerKM = farePerKM;
        }

        public virtual double CalculateTotalFare()
        {
            return this.distance*this.farePerKM;
        }

   }
}
