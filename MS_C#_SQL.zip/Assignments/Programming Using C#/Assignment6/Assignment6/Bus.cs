﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment6
{
    public class Bus:Vehicle
    {


        #region Do Not Modify
        public Bus()
        {

        }
        #endregion

        public Bus(double farePerKM,int distance,int vehicleNumber) : base(farePerKM, distance)
        {
            this.vehicleId = "B" + vehicleNumber.ToString();
        }

        public override double CalculateTotalFare()
        {

            double totalFare = base.CalculateTotalFare();
            if (totalFare > 1000)
            {
                totalFare += totalFare * 0.02;
            }
            return totalFare;

        }
    }
}
