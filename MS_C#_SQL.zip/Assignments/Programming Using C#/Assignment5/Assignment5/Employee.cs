﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment5   
{
    public class Employee
    {
        public int fixedSalary;
        public DateTime workingFrom;
        Department dept = new Department();


        private double GetAllowance()
        {
            DateTime cutOffDate = Convert.ToDateTime("31-Mar-2014");
            double allowance = GetAllowance(cutOffDate);
            return allowance=GetAllowance(cutOffDate); 
            
        }
        
        private double GetAllowance(DateTime cutOffDate)
        {
            double allowance = 0;
            int workingdays = (cutOffDate - workingFrom).Days;
            double workexperience = workingdays / 365;
            if (workexperience < 5)
            {
                allowance = 5 * fixedSalary / 100;
            }
            else if (workexperience >= 5 && workexperience < 10)
            {
                allowance = 10 * fixedSalary / 100;
            }
            else if (workexperience >= 10 && workexperience < 15)
            {
                allowance = 15 * fixedSalary / 100;
            }
            else if (workexperience >= 15)
            {
                allowance = 20 * fixedSalary / 100;
            }
            return allowance;

        }

    

    public double GetTotalSalary(float multiplyfactor)
        {
            double totalSalary = fixedSalary + GetAllowance() + dept.GetIncentive(multiplyfactor);
            return totalSalary;
        }

        public double GetTotalSalary(DateTime cutOffDate,float multiplyfactor)
        {
            double totalSalary=fixedSalary+GetAllowance(cutOffDate)+dept.GetIncentive(multiplyfactor);
            return totalSalary;
        }


    }

   
}
