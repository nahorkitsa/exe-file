﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment5
{
    public class Department
    {
        public int deptNumber;
        public bool isProducing;
        public float produce;


        public float GetIncentive(float multiplyfactor)
        {
            float incentive;
            if (isProducing == true)
            {
                incentive = this.produce * multiplyfactor;
            }
            else
            {
                incentive = 0;
            }
            return incentive;
        }
    }

    
}
