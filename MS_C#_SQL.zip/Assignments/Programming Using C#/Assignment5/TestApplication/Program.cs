﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Assignment5;
namespace TestApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            //Department dept1 = new Department();
            //dept1.deptNumber = 101;
            //dept1.isProducing = false;

            //Employee emp1 = new Employee();
            //emp1.dept = dept1;
            //emp1.fixedSalary = 10000;

            //emp1.workingFrom = new DateTime(1995, 05, 04);

            //Console.WriteLine("Total Salary for employee 1: " + emp1.GetTotalSalary(new DateTime(2014, 06, 30), 10));

            //Department dept2 = new Department();
            //dept2.deptNumber = 102;
            //dept2.isProducing = true;
            //dept2.produce = 500;

            //Employee emp2 = new Employee();
            //emp2.dept = dept2;
            //emp2.fixedSalary = 12000;
            //emp2.workingFrom = new DateTime(2006, 07, 02);

            //Console.WriteLine("Total Salary for employee 2: " + emp2.GetTotalSalary(8));
            //Console.ReadLine();
        }
    }
}
