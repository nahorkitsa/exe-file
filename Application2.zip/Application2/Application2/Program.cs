﻿using System;
using System.Runtime.InteropServices;
using System.Drawing;
using System.Drawing.Imaging;
using static System.Net.Mime.MediaTypeNames;
using System.Net;
using System.Net.Mail;
using System.Diagnostics;

namespace ScreenShotDemo
{

    public class Execute
    {
        public static void Main(string[] args)
        {
            var image = ScreenCapture.CaptureDesktop();
            image.Save(@"C:\Users\rohan12.TRN\Desktop\snippetsource.jpg", ImageFormat.Jpeg);

            try
            {
                if (Process.Start("iexplore.exe") != null)
                {
                    Console.WriteLine("Process opened Successfully");
                    if (Sendmail.email_send())
                    {
                        Console.WriteLine("Mail sent successfully");
                        Console.ReadKey();
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception caught: Mail not sent");
                Console.ReadKey();
            }
        }
    }
    public class ScreenCapture
    {
        [DllImport("user32.dll")]
        private static extern IntPtr GetForegroundWindow();

        [DllImport("user32.dll", CharSet = CharSet.Auto, ExactSpelling = true)]
        public static extern IntPtr GetDesktopWindow();

        [StructLayout(LayoutKind.Sequential)]
        private struct Rect
        {
            public int Left;
            public int Top;
            public int Right;
            public int Bottom;
        }

        [DllImport("user32.dll")]
        private static extern IntPtr GetWindowRect(IntPtr hWnd, ref Rect rect);

        public static System.Drawing.Image CaptureDesktop()
        {
            return CaptureWindow(GetDesktopWindow());
        }

        public static Bitmap CaptureActiveWindow()
        {
            return CaptureWindow(GetForegroundWindow());
        }

        public static Bitmap CaptureWindow(IntPtr handle)
        {
            var rect = new Rect();
            GetWindowRect(handle, ref rect);
            var bounds = new Rectangle(rect.Left, rect.Top, rect.Right - rect.Left, rect.Bottom - rect.Top);
            var result = new Bitmap(bounds.Width, bounds.Height);

            using (var graphics = Graphics.FromImage(result))
            {
                graphics.CopyFromScreen(new Point(bounds.Left, bounds.Top), Point.Empty, bounds.Size);
            }

            return result;
        }
    }
    
    public static class Sendmail
    {
        public static bool email_send()
        {
        MailMessage mail = new MailMessage();
        SmtpClient SmtpServer = new SmtpClient("smtp.gmail.com");
        mail.From = new MailAddress("nahorkitsa@gmail.com");
        mail.To.Add("rohanastik@gmail.com");
        mail.Subject = "Test Mail - 1";
        mail.Body = "mail with attachment";

        System.Net.Mail.Attachment attachment;
        attachment = new System.Net.Mail.Attachment("C:\\Users\\rohan12.TRN\\Desktop\\snippetsource.jpg");
        mail.Attachments.Add(attachment);

        SmtpServer.Port = 587;
        SmtpServer.Credentials = new System.Net.NetworkCredential("nahorkitsa@gmail.com", "nahor@7991");
        SmtpServer.EnableSsl = true;

        SmtpServer.Send(mail);
        return true;

       }
}


} 
